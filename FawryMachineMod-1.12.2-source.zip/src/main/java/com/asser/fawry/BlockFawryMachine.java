package com.asser.fawry;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockFawryMachine extends Block {
    public BlockFawryMachine() {
        super(Material.IRON);
        setHardness(3.0F);
        setResistance(8.0F);
    }

    @Override
    public boolean onBlockActivated(World world, BlockPos pos, IBlockState state,
                                    EntityPlayer player, EnumHand hand,
                                    net.minecraft.util.EnumFacing side,
                                    float hitX, float hitY, float hitZ) {
        if (!world.isRemote) {
            player.openGui(FawryMod.INSTANCE, 0, world, pos.getX(), pos.getY(), pos.getZ());
        }
        return true;
    }
}
