package com.asser.fawry;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;

public class ContainerFawry extends Container {
    @Override
    public boolean canInteractWith(EntityPlayer player) {
        return true;
    }
}
