package com.asser.fawry;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import java.io.IOException;

public class GuiFawry extends GuiScreen {
    private String message = "Choose a demo service";

    @Override
    public void initGui() {
        int left = (width - 220) / 2;
        int top = (height - 150) / 2;
        buttonList.clear();
        buttonList.add(new GuiButton(0, left + 10, top + 48, 200, 20, "Mobile recharge"));
        buttonList.add(new GuiButton(1, left + 10, top + 73, 200, 20, "Internet bill"));
        buttonList.add(new GuiButton(2, left + 10, top + 98, 200, 20, "Electricity bill"));
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 0) message = "Demo: Mobile recharge selected";
        if (button.id == 1) message = "Demo: Internet bill selected";
        if (button.id == 2) message = "Demo: Electricity bill selected";
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int left = (width - 220) / 2;
        int top = (height - 150) / 2;
        drawRect(left, top, left + 220, top + 150, 0xFF222222);
        drawCenteredString(fontRenderer, "FAWRY MACHINE", width / 2, top + 12, 0xFFFFD21F);
        drawCenteredString(fontRenderer, message, width / 2, top + 32, 0xFFFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
