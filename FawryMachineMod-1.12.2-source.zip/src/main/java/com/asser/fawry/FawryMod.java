package com.asser.fawry;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.network.NetworkRegistry;

@Mod(modid = FawryMod.MODID, name = FawryMod.NAME, version = FawryMod.VERSION)
public class FawryMod {
    public static final String MODID = "fawrymachine";
    public static final String NAME = "Fawry Machine";
    public static final String VERSION = "1.0.0";

    public static Block FAWRY_MACHINE;
    public static FawryMod INSTANCE;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        INSTANCE = this;
        FAWRY_MACHINE = new BlockFawryMachine();
        FAWRY_MACHINE.setRegistryName(MODID, "fawry_machine");
        FAWRY_MACHINE.setUnlocalizedName(MODID + ".fawry_machine");
        FAWRY_MACHINE.setCreativeTab(CreativeTabs.DECORATIONS);
        GameRegistry.register(FAWRY_MACHINE);
        GameRegistry.register(new ItemBlock(FAWRY_MACHINE).setRegistryName(FAWRY_MACHINE.getRegistryName()));
        NetworkRegistry.INSTANCE.registerGuiHandler(this, new FawryGuiHandler());
    }
}
