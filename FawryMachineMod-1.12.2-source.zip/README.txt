FAWRY MACHINE MOD - Minecraft Java 1.12.2
Author label: Asser Mostafa

This is a Forge mod source project. It adds a placeable Fawry-style machine block.
Right-click it to open a demo menu with three fictional services. It does NOT connect
to real Fawry, banks, cards, mobile networks, or payment systems.

BUILD REQUIREMENTS
- Minecraft Forge 1.12.2, recommended Forge 14.23.5.2860
- Java JDK 8 (not a newer Java version)
- Gradle / ForgeGradle 2.3

BUILD
1. Install JDK 8.
2. Install the Forge 1.12.2 MDK for 14.23.5.2860.
3. Put these project files into a ForgeGradle 2.3 workspace, or open this folder
   in a compatible Gradle environment.
4. Run: gradlew build
5. The built mod jar will be in build/libs.

NOTE
This archive contains source code, not a precompiled .jar. The GUI is a basic
starter demo. The block texture is a simple generated placeholder.
